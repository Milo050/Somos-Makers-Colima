import React from "react";
import Tienda from "./Tienda";

function App() {
  return <Tienda />;
}

export default App;